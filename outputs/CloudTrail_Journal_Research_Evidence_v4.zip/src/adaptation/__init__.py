"""Protected selective adaptation policies."""
