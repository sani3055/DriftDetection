"""Interpretable dual-signal drift diagnosis and validation-only threshold tuning."""

from __future__ import annotations

from itertools import product
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score


def diagnose(feature_score: float, shap_score: float, feature_threshold: float, shap_threshold: float) -> str:
    feature_high = feature_score >= feature_threshold
    shap_high = shap_score >= shap_threshold
    if not feature_high and not shap_high:
        return "stable"
    if feature_high and not shap_high:
        return "benign_drift"
    if feature_high and shap_high:
        return "security_relevant_drift"
    return "review_required"


def diagnose_coupled(
    feature_score: float,
    shap_score: float,
    coupling_score: float,
    feature_threshold: float,
    shap_threshold: float,
    coupling_threshold: float,
) -> str:
    """Diagnose drift using signal magnitude plus feature-attribution alignment."""
    feature_high = feature_score >= feature_threshold
    shap_high = shap_score >= shap_threshold
    coupling_high = coupling_score >= coupling_threshold
    if not feature_high and not shap_high:
        return "stable"
    if feature_high and not shap_high:
        return "benign_drift"
    if not feature_high and shap_high:
        return "hidden_model_instability" if not coupling_high else "review_required"
    return "security_relevant_drift" if coupling_high else "review_required"


def largest_gap_threshold(values: Iterable[float], fallback: float = 0.5) -> float:
    """Choose a label-free threshold at the largest observed score gap.

    This is intended for a target-window transfer calibration experiment. It uses
    only unlabeled coupling scores and falls back to a conservative midpoint when
    fewer than two finite, non-identical scores are available.
    """
    scores = np.asarray([float(value) for value in values if np.isfinite(float(value))], dtype=float)
    scores = np.unique(np.sort(scores))
    if len(scores) < 2:
        return float(fallback)
    gaps = np.diff(scores)
    index = int(np.argmax(gaps))
    if gaps[index] <= 0:
        return float(fallback)
    return float((scores[index] + scores[index + 1]) / 2.0)


def _labels(frame: pd.DataFrame) -> list[str]:
    return frame["ground_truth"].replace({"benign_region": "benign_drift", "benign_identity": "benign_drift", "benign_service": "benign_drift", "security_privilege": "security_relevant_drift", "security_defense": "security_relevant_drift", "security_credential": "security_relevant_drift", "stable": "stable"}).tolist()


def tune_thresholds(validation: pd.DataFrame) -> dict[str, float]:
    """Tune both thresholds on validation scenarios only."""
    feature_candidates = np.unique(np.quantile(validation["feature_drift_score"], [0.2, 0.35, 0.5, 0.65, 0.8, 0.9]))
    shap_candidates = np.unique(np.quantile(validation["shap_drift_score"], [0.2, 0.35, 0.5, 0.65, 0.8, 0.9]))
    truth = _labels(validation)
    best = None
    for feature_threshold, shap_threshold in product(feature_candidates, shap_candidates):
        predictions = [
            diagnose(f, s, float(feature_threshold), float(shap_threshold))
            for f, s in zip(validation["feature_drift_score"], validation["shap_drift_score"])
        ]
        score = f1_score(truth, predictions, labels=["stable", "benign_drift", "security_relevant_drift"], average="macro", zero_division=0)
        candidate = (float(score), float(feature_threshold), float(shap_threshold))
        if best is None or candidate > best:
            best = candidate
    assert best is not None
    return {
        "feature_threshold": best[1],
        "shap_threshold": best[2],
        "validation_macro_f1": best[0],
    }


def tune_coupled_thresholds(
    validation: pd.DataFrame,
    coupling_column: str = "feature_attribution_coupling",
    threshold_key: str = "coupling_threshold",
) -> dict[str, float]:
    """Tune feature, SHAP, and one coupling score using validation scenarios only."""
    feature_candidates = np.unique(np.quantile(validation["feature_drift_score"], [0.2, 0.35, 0.5, 0.65, 0.8, 0.9]))
    shap_candidates = np.unique(np.quantile(validation["shap_drift_score"], [0.2, 0.35, 0.5, 0.65, 0.8, 0.9]))
    coupling_candidates = np.unique(np.quantile(validation[coupling_column], [0.2, 0.35, 0.5, 0.65, 0.8, 0.9]))
    truth = _labels(validation)
    best = None
    for feature_threshold in feature_candidates:
        for shap_threshold in shap_candidates:
            for coupling_threshold in coupling_candidates:
                predictions = [
                    diagnose_coupled(f, s, c, float(feature_threshold), float(shap_threshold), float(coupling_threshold))
                    for f, s, c in zip(
                        validation["feature_drift_score"],
                        validation["shap_drift_score"],
                        validation[coupling_column],
                    )
                ]
                score = f1_score(
                    truth,
                    predictions,
                    labels=["stable", "benign_drift", "security_relevant_drift", "hidden_model_instability", "review_required"],
                    average="macro",
                    zero_division=0,
                )
                candidate = (float(score), float(feature_threshold), float(shap_threshold), float(coupling_threshold))
                if best is None or candidate > best:
                    best = candidate
    assert best is not None
    return {
        "feature_threshold": best[1],
        "shap_threshold": best[2],
        threshold_key: best[3],
        "validation_macro_f1": best[0],
    }


def apply_diagnosis(frame: pd.DataFrame, thresholds: dict[str, float]) -> pd.DataFrame:
    result = frame.copy()
    result["diagnosis"] = [
        diagnose(f, s, thresholds["feature_threshold"], thresholds["shap_threshold"])
        for f, s in zip(result["feature_drift_score"], result["shap_drift_score"])
    ]
    return result


def apply_coupled_diagnosis(
    frame: pd.DataFrame,
    thresholds: dict[str, float],
    coupling_column: str = "feature_attribution_coupling",
    threshold_key: str = "coupling_threshold",
    output_column: str = "coupled_diagnosis",
) -> pd.DataFrame:
    result = frame.copy()
    result[output_column] = [
        diagnose_coupled(
            f,
            s,
            c,
            thresholds["feature_threshold"],
            thresholds["shap_threshold"],
            thresholds[threshold_key],
        )
        for f, s, c in zip(
            result["feature_drift_score"],
            result["shap_drift_score"],
            result[coupling_column],
        )
    ]
    return result
