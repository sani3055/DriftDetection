"""Research pipeline package."""
